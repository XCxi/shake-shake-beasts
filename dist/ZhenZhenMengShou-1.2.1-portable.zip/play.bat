@echo off
setlocal
cd /d "%~dp0"
set "GAME=%~dp0game.html"
set "URL=file:///%GAME:\=/%"
set "BROWSER="
for %%P in ("%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe") do if not defined BROWSER if exist %%P set "BROWSER=%%~P"
if defined BROWSER (
  start "" "%BROWSER%" --app="%URL%" --window-size=560,940
) else (
  start "" "%GAME%"
)
exit /b 0
