﻿震震萌兽 v1.2.1 桌面版（便携）

怎么玩：双击 play.bat —— 会用 Edge/Chrome 的应用模式打开，没有地址栏，像原生小游戏。
        也可以直接双击 game.html（会有浏览器工具栏）。

装快捷方式：双击 install.cmd —— 装到 %LOCALAPPDATA%\ZhenZhenMengShou，并建桌面 + 开始菜单快捷方式。
卸载：运行安装目录下的 uninstall.cmd。

完全离线：不联网、无广告、无后端，存档在本机浏览器里。

四种玩法：15 关战役 / 无尽模式 / 限时 60 秒 / 今日挑战
核心操作：敲一下 → 冲击波扩散 → 萌兽被掀起来互撞 → 撞得够狠才合体
每关还有 💥 重锤 与 🧲 磁锤 各一次

在线版：https://xcxi.github.io/shake-shake-beasts/
