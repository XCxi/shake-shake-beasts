﻿震震萌兽 v1.2.1 便携版

怎么玩：双击 play.bat（会用 Edge/Chrome 的应用模式打开，没有地址栏，像原生小游戏）
        也可以直接双击 game.html，效果一样，只是会有浏览器工具栏。

完全离线：没有联网、没有广告、没有后端，存档在本机浏览器里。

想装成快捷方式：双击 install.cmd（装到 %LOCALAPPDATA%\ZhenZhenMengShou 并建桌面快捷方式）

玩法：无限模式 / 限时 60 秒 / 15 关战役 / 今日挑战
      敲一下 → 冲击波扩散 → 萌兽被掀起互撞 → 撞得够狠才合体
      每关还有 💥 重锤 与 🧲 磁锤 各一次

在线版：https://xcxi.github.io/shake-shake-beasts/
